#!/usr/bin/env python
# coding: utf-8

# In[5]:


# Admin Log
# This is the main Module of the Project
# import issuestu
from time import gmtime, strftime # Module 1
import time #Module 1

import subprocess as sp # Module 2 To execute or use Compile and run function during some condition of shell
sp.call('cls',shell=True) #Module 2

t = time.localtime()
current_time = time.strftime("%H:%M:%S", t)
print(current_time)
print("\t\t\t\t\t\t\t\t\t\t\t\t\t\t",strftime("%Y-%m-%d ", gmtime()))
print('\033[92m'+"\t\t\t\t**********************LIBRARY MANAGEMENT SYSTEM***********************]")
print("\n\n\n Welcome ! To Sistec  : \n")
print(" Press 1 : Add/Remove Student : ")
print(" Press 2 : Add/Remove Faculty :")
print(" Press 3 : Add  Book :")
print(" Press 4: Issue Book for Student:")
print("Press 5: Issue Book for Faculty : ")
print("Press 6: Student Book Return :")
print("Press 7: Faculty Book Return :")
print("Press 8 : To go back to Main Menu :")
mode1 = input("\nSelect Your Mode Of Operatin : ")
if mode1 == '1':
    exec(compile(open( "AddStudent.py").read(), "AddStudent.py", 'exec'))
    
elif mode1 == '2':
    exec(compile(open( "AddFaculty.py").read(), "AddFaculty.py", 'exec'))
    
elif mode1 == '3':
    exec(compile(open( "Bookdiction.py").read(), "Bookdiction.py", 'exec'))
        
elif mode1 == '4':
    exec(compile(open( "issuestu.py").read(), "issuestu.py", 'exec'))    
elif mode1 == '5':
    exec(compile(open( "bookissueFac.py").read(), "bookissueFac.py", 'exec'))    
elif mode1 == '6':
    exec(compile(open( "BookReturn.py").read(), "BookReturn.py", 'exec'))    
elif mode1 == '7':
    exec(compile(open( "bookreturnFac.py").read(), "bookreturnFac.py", 'exec')) 

elif mode1 == '8':
    exec(compile(open( "Main.py").read(), "Main.py", 'exec'))     
    
else:
    print("You entered a InValid Option : ")
    
    
    
    
    







