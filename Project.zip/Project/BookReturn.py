

import pickle
from datetime import datetime
import pickle
def return_Book():
    with open('addstudent.pkl','rb') as f:
        student = pickle.load(f)
        rollno = input('Enter the Enrollment No: ')
        i = 0
        c = 0
        isbnNo = int(input('Enter the isbnNo: '))
        while True:
            try:
                if student[i].enroll == rollno:
                    with open('Bookdict3.pkl','rb') as f1:
                        books = pickle.load(f1)
                        for bookName,authList in books.items():
                            for auth in authList:
                                for authName,isbnList in auth.items():
                                    c = 1
                                    if isbnNo == isbnList[0]:
                                        k = 0
                                        for j in student[i].listissue:
                                            if j == isbnNo:
#                                                 student[i].dateOfIssue.pop(k)
#                                                 student[i].returnDate.pop(k)
                                                break
                                            else:
                                                k = k + 1
                                        student[i].listissue.remove(isbnNo)
                                        isbnList[1] += 1
                                        break
                                        
                            
                if c == 1:
                    print('Book Returned')
                    break
                i = i + 1
            except:
                print('Book Not Found')
                break
        with open('Bookdict3.pkl','wb') as f2:
            pickle.dump(books,f2)
    with open('addstudent.pkl','wb') as f3:
        pickle.dump(student,f3)
return_Book()






