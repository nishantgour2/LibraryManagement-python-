#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!/usr/bin/env python
# coding: utf-8

# In[19]:

from datetime import datetime

import pickle
import datetime
def issue_Books():
    with open('addstudent.pkl','rb') as f:
        stu = pickle.load(f)
        rollno = input('Enter the Enrollment No: ')
        i = 0
        c = 0
        while True:
            try:
                if stu[i].enroll == rollno:
                    if len(stu[i].listissue) == 5:
                        print('Limit Reached')
                        break
                    with open('Bookdict3.pkl','rb') as f1:
                        books = pickle.load(f1)
                        isbnNo = int(input('Enter the isbnNo: '))
                        for bookName,authList in books.items():
                            for auth in authList:
                                for authName,isbnList in auth.items():
                                    if isbnList[0] == isbnNo:
                                        if isbnList[1] > 0:
                                            c = 1
                                            stu[i].listissue.append(isbnNo)
                                            isbnList[1] -= 1
#                                             student[i].dateOfIssue.append(datetime.date.today())
#                                             student[i].returnDate.append(datetime.date.today() + datetime.timedelta(3*365/12))
                                            with open('Bookdict3.pkl','wb') as f2:
                                                pickle.dump(books,f2)
                if c == 1:
                    print('Book Issued')
                    break
                i = i + 1
            except:
                print('Book Not Found')
                break
    with open('addstudent.pkl','wb') as f3:
        pickle.dump(stu,f3)
issue_Books()

while True:
    print("Press 1: To go to the main menu")
    print("Press 2: to exit")
    opt=input()
    if opt == '1':
        exec(compile(open( "Admin.py").read(), "Admin.py", 'exec'))
        
        
    elif opt=='2':
        sys.exit()
        
        
    else:
        print("Please enter a valid choice")






        

