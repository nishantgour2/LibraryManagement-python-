#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!/usr/bin/env python
# coding: utf-8

# In[11]:


# prevAdmin.py file

from time import gmtime, strftime
import getpass
import time
t = time.localtime()

import subprocess as sp # Module 2 To execute or use Compile and run function during some condition of shell
sp.call('cls',shell=True)#Module 2

current_time = time.strftime("%H:%M:%S", t)
print(current_time)
print("\t\t\t\t\t\t\t\t\t\t\t\t\t\t",strftime("%Y-%m-%d ", gmtime()))
print("\t\t\t**********************LIBRARY MANAGEMENT SYSTEM***********************")
print('\n\t\t\t\t \t<-----Welcome To The Student Module----->')
enroll = input("Enter The Code To Enter: ")
enroll.lower()
# print('Enter the password : ')
# passw  = getpass.getpass() 

if enroll =='hail Hydra':
        exec(compile(open( "Admin.py").read(), "Admin.py", 'exec'))
        
        
else:
    print("Warning !")
    print("Please Enter The Valid Code")
    



# In[ ]:




