import pickle #This is the final module of add Faculty. 
class student:
    
    def getdata(s):
        s.year = input("Enter the year of admission")
        s.no = input("Enter the admission number")
        
        s.branch = input("Enter the Branch of the The student ")
        s.name = input("Enter The Name Of The student : ")
        s.enroll = s.year + '0187' + s.branch + s.no
        s.listissue = []
        s.listfine = []
        s.issuedate = []
        s.issuereturn =[]
        
    def display(s):
        print("\n\n Faculty Details")
        print('\nName',s.name)
        print('ID ',s.enroll)
        print("Branch",s.branch)
        print("Total Book Issued",s.listissue)
        print("Fine per isbn",s.listfine)
        print("Issue date",s.issuedate)
        print("Return Date,",s.issuereturn)
        
    def rem(s):
        del s.enroll,s.branch,s.name,s.listfine,s.listissue
        
    def picklefun(self):
#         with open('addstudentfina.pkl','wb') as f:
            pickle.dump(listdata,f)    
        

listdata=[]
while True:
    print("press 1 : To Add student ")
    print("press 2 : To Display student record ")
    print("Press 3: To Remove student record ")
    print("press 4: To exit ")
    print("press 5: to go back the the admin ")
    o=input()

    if o=='1':
    #     DO NOT DELETE THESE COMMENT 
#         with open ("addstudent.pkl",'wb') as f:
#             n = int(input("Enter the number of record u want :"))
#             for k in range(n):
#                 i = student()
#                 i.getdata()

#                 listdata.append(i)
# #                 i.picklefun()

#             pickle.dump(listdata,f)   


        with open ("addstudent.pkl",'rb') as f:
            obj = pickle.load(f)
            n = int(input("Enter the number of record u want :"))
            for i in range(n):
                i = student()
                listdata.append(i)
                i.getdata()
                obj.append(i)
            with open('addstudent.pkl','wb') as f:
                pickle.dump(obj,f)
        print("record updated succeessfully")


    elif o == '2':            
        with open ('addstudent.pkl','rb') as f:
            while True :
                try:
                    obj = pickle.load(f)
                    for i in obj:
                        i.display()

                except EOFError:
                    print("Data read complete")
                    break
    elif o=='3':
        with open ("addstudent.pkl",'rb') as f:
            obj = pickle.load(f)
            n = (input("Enter the Faculty Id You Want to Delete :"))
            for i in range(0,len(obj)):
                if n!=obj[i].enroll:
                    print("Invalid input")
                    break

            for i in range(0,len(obj)):
                if n==obj[i].enroll:
                    del obj[i]

    #             else : 
    #                 print("Please Enter a valid Id")


            with open('addstudent.pkl','wb') as f:
                pickle.dump(obj,f)
        print("Record updated succeessfully")


    elif o=='4':
        break
        
    elif o=='5':
        exec(compile(open( "Admin.py").read(), "Admin.py", 'exec'))
        
        
    else:
        print("Ivalid input ! Please Try Again")


    
