#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!/usr/bin/env python
# coding: utf-8

# In[19]:

#Book Issue For Faculty
import pickle
class book_Issuef:
    i = 0
    def bookIssue(self):
        rollno = input('Enter the Faculty Id: ')
        with open('addfacultyfina.pkl','rb') as f1:
            o = pickle.load(f1)
            for i in range(0,len(o)):
#                 try:
                if (o[i].enroll == rollno):
                    print('Name Found ',o[i].name)
                    n = int(input('Enter isbn No ?'))
                    with open('Bookdict3.pkl','rb') as f:
                        obj = pickle.load(f)
                        for key,val in obj.items():
                            for u in val:
                                for j,k in u.items():
                                    for isbn in k:
                                        if isbn == int(n):
                                            print('Book Found')
                                            o[i].listissue.append(int(n))
                                            k.remove(int(n))
                                            print('Task complete')
                                            break
#                 except:
#                     print('Task Completed')
#                     break
        with open('addfacultyfina.pkl','wb') as f4:
            pickle.dump(o,f4)
                
                    
                                            

b = book_Issuef()
b.bookIssue()
# input()






