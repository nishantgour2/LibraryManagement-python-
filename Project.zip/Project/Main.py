#!/usr/bin/env python
# coding: utf-8

# In[2]:


# This is the main Module of the Project
from time import gmtime, strftime # Module 1
import time #Module 1
import sys

import subprocess as sp # Module 2 To execute or use Compile and run function during some condition of shell
sp.call('cls',shell=True) #Module 2

t = time.localtime()
current_time = time.strftime("%H:%M:%S", t)
print(current_time)
print("\t\t\t\t\t\t\t\t\t\t\t\t\t\t",strftime("%Y-%m-%d ", gmtime()))
print('\033[92m'+"\t\t**********************LIBRARY MANAGEMENT SYSTEM***********************]")
print("\n\n\n Mode Of LOGIN : \n")
while True:
    print(" Press 1 : Student/Faculty ")
    print(" Press 2 : Admin  : ")
    print("Press 3: To exit : ")
    mode = input("\nSelect Your Mode Of Login : ")

    if mode == '1':
        exec(compile(open( "Studentlog1.py").read(), "Studentlog1.py", 'exec'))

   

    elif mode == '2':
        exec(compile(open( "Adminlog.py").read(), "Adminlog.py", 'exec'))

    elif mode == '3':
         sys.exit()


    else:
        print("Please Enter The Valid Mode ")











