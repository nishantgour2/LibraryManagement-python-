#!/usr/bin/env python
# coding: utf-8

# In[22]:


class book:
    
    def __init__(self):
        
        
        
        self.d1={'Algorithms and data structures':[{'Narshima':[12651,16511,1561]},{'Balaguruswami':[12651,16611,15051]}],
                 'Artificial intelligence':[{'Sahani':[346512,325311,143431]},{'Balaguruswami':[172651,564511,4553261]}],
                 'Computational science':[{'Sahani':[346591,328511,147331]},{'Balaguruswami':[178451,5667641,555361]}],
                 'Computer architecture':[{'Sahani':[3465541,324511,143531]},{'Balaguruswami':[17450801,5067641,55761]}],
                 'Computer graphics':[{'Sahani':[34654561,32456511,1454331]},{'Balaguruswami':[1740051,567641,508561]}],
                 'Computer security':[{'Sahani':[3465431,3251341,1433451]},{'Balaguruswami':[174501,56706451,555461]}],
                 'Concurrency (computer science)':[{'Sahani':[346451,3234511,1423331]},{'Balaguruswami':[175451,5467641,53561]}],
                 'Database theory':[{'Sahani':[346541,3267511,1433341]},{'Balaguruswami':[174518,5677641,55561]}],
                 'Formal methods':[{'Sahani':[346531,32342511,143331]},{'Balaguruswami':[174519,5676401,50561]}],
                 'Human-based computation':[{'Sahani':[3465231,3452511,146331]},{'Balaguruswami':[174511,567641,55612]}],
                 'Human–computer interaction':[{'Sahani':[3465781,325811,143301]},{'Balaguruswami':[174541,5657641,51561]}],
                 'Mathematical optimization':[{'Sahani':[3465651,3212511,1423331]},{'Balaguruswami':[174551,5676741,505651]}],
                 'Programming language theory':[{'Sahani':[3467651,325611,143341]},{'Balaguruswami':[107451,50676041,530561]}],
                 'Soft computing':[{'Sahani':[34651,3251451,1433871]},{'Balaguruswami':[174501,5676410,55610]}],
                 'Theoretical computer science':[{'Sahani':[3412651,325131,140331]},{'Balaguruswami':[1712451,56237641,55361]}],
                 'Theory of computation':[{'Sahani':[346751,325171,1433100]},{'Balaguruswami':[171451,5627641,55361]}]
                 
                 
                 
                }

        for k,v in self.d1.items():
            for i in v:
                for j,l in i.items():
                    print('Book Name is :',k)
                    print('Author Name is :',j)
                    print('isbn No are:')
                    for isbn in l:
                        print(isbn)
        
        
            
        
        
        
        

    
b = book()       
# print(b.d1)
while True:
    print("press 1: to go to back to the main menu")
    opt=input()
    if opt == '1':
        exec(compile(open( "Main.py").read(), "Main.py", 'exec'))

    else:
        print("Invalid ! input")










