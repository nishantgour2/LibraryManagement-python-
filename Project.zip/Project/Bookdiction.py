#!/usr/bin/env python
# coding: utf-8

# In[12]:


#!/usr/bin/env python
# coding: utf-8

# In[3]:
import pickle
import sys

class bookAdd:
    
    def getdata(self):  
        self.d1={'Algorithms and data structures':[{'Narshima':[12651,10]},{'Balaguruswami':[12651,16611,15051]}],
                 'Artificial intelligence':[{'Sahani':[346512,15]},{'Balaguruswami':[172651,11]}],
                 'Computational science':[{'Sahani':[346591,2]},{'Balaguruswami':[178451,25]}],
                 'Computer architecture':[{'Sahani':[3465541,3]},{'Balaguruswami':[17450801,5]}],
                 'Computer graphics':[{'Sahani':[34654561,8]},{'Balaguruswami':[1740051,14]}],
                 'Computer security':[{'Sahani':[3465431,7]},{'Balaguruswami':[174501,22]}],
                      
                }
        
        
        
        import pickle
        with open("Bookdict3.pkl","wb") as f1:
            pickle.dump(self.d1,f1)

                                
    def updateq(s):
        import pickle
#         with open ('Bookdict3.pkl','rb') as f1:
#             obj = pickle.load(f1)

        s.i = list()
        s.ca = list()
        s.n = dict()
        print("What do you want to update")
        print("Press 1 : To update a new book-categ ")
        opt=input()    
        if opt == '1':
            with open('Bookdict3.pkl','rb') as f:
                books = pickle.load(f)
                bookN = input('Enter Name of Book: ')
                authN = input('Enter Author Name: ')
                isbnn = int(input('Enter isbn No'))
                copy = int(input("Enter the number of copy"))
                while True:
                    if len(str(isbnn)) == 13:
                        break
                    else:
                        print('Invalid Input')
                        isbnn = int(input('Enter isbn No'))
                try:
                   
                    for s.bookName,s.authList in books.items():
                        for auth in s.authList:
                            for authName,isbnList in auth.items():
                                if isbnList[0] == isbnn:
                                    print('isbn No Already Exist')
                                    sys.exit(0)
                                    
                                
                                   
                except:
                    pass
                
#                 s.i.append(s.isbnno)
#                 s.i.append(s.copy)
#                 s.n.update({s.authName:s.isbnno})
#                 s.ca.append(s.n)
#                 books.update({s.bookName:s.ca}) 
#                 noofcopies = int(input('Enter No of Copies'))
                books.update({bookN:[{authN:[isbnn,copy]}]})
            with open('Bookdict3.pkl','wb') as f:
                pickle.dump(books,f)


    
d1 = bookAdd()
# d1.getdata()
# print(d1)
while True:
    print("Press 1: To Go To Book menu")
    print("Press 2: To Go Back To The Main Menu " )
    print("Press 3: To Exit")
    option = input()
    if option == '1':
        import pickle
        with open ('Bookdict3.pkl','rb') as f1:
#                 while True :
#                     try:

                    obj = pickle.load(f1)
                    print("Press 1 to display book")
                    print("press 2 to update :")
                    o = input("Enter Your Choice : ")
                    if o=='1':
                        for bookName,authList in obj.items():
                            for auth in authList:
                                for authName,isbnList in auth.items():
                                    print('Book Name is: ',bookName)
                                    print('Author of Book is: ',authName)
                                    print('isbn No of Book: ',isbnList[0])
                                    print('No of Copies: ',isbnList[1])


                    if o == '2':
                        d1.updateq()              

#                     except:
#                         print("Data read complete")
#                         break



    elif option =='2':
        exec(compile(open( "Admin.py").read(), "Admin.py", 'exec'))
        
    elif option == '3':
        sys.exit()
        
    else:
        print("please enter a valid input")
        







