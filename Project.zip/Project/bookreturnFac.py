#!/usr/bin/env python
# coding: utf-8

# In[15]:


#!/usr/bin/env python
# coding: utf-8

# In[29]:


import pickle
class book_return:
    i = 0
    def bookreturn(self):
        rollno = input('Enter the Roll No: ')
        with open('addfacultyfina.pkl','rb') as f1:
            o = pickle.load(f1)
            for i in range(0,len(o)):
#                 try:
                if (o[i].enroll == rollno):
                    print('Name Found ',o[i].name)
                    n = int(input('Enter isbn No ?'))
                    with open('Bookdict3.pkl','rb') as f:
                        obj = pickle.load(f)
                        for key,val in obj.items():
                            for u in val:
                                for j,k in u.items():
                                    for isbn in k:
                                        if isbn == int(n):
                                            print('Book Found')
                                            o[i].listissue.remove(isbn)
                                            k.append(isbn)
                                            print('Task completed')
                                            break
#                 except:
#                     print('Task Completed')
#                     break
        with open('addfacultyfina.pkl','wb') as f4:
            pickle.dump(o,f4)
                
                    
                                            

b = book_return()
b.bookreturn()



# In[ ]:




