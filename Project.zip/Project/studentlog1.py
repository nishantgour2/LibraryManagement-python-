#!/usr/bin/env python
# coding: utf-8

# In[6]:


# Student log1 File 

from time import gmtime, strftime # Module 1
import time #Module 1

import subprocess as sp # Module 2 To execute or use Compile and run function during some condition of shell
sp.call('cls',shell=True) #Module 2


t = time.localtime()
current_time = time.strftime("%H:%M:%S", t)
print(current_time)
print("\t\t\t\t\t\t\t\t\t\t\t\t\t\t",strftime("%Y-%m-%d ", gmtime()))
print("\t\t**********************LIBRARY MANAGEMENT SYSTEM***********************")
print("\n\n\n What Do You Want To Do  : \n")
print(" 1 : See All Book Category ")
print(" 2 : See All Books ")
# print(" 3 : Issue Books ")
# print(" 4 : Book Return")
# print(" 5 : See Your Fine")

sel = input(" Select Your Choice ")
if sel == '1':
    exec(compile(open( "book_cat.py").read(), "book_cat.py", 'exec'))

    

elif sel == '2':
    exec(compile(open( "see_book.py").read(), "see_book.py", 'exec'))
    
else:
    print("Wrong Choice  ! Connection failed.")

    

# elif sel == '3':
#     exec(compile(open( "book_issue.py").read(), "book_issue.py", 'exec'))


# elif sel == '4':
#     exec(compile(open( "book_return.py").read(), "book_return.py", 'exec'))


# elif sel == '5':
#     exec(compile(open( "see_fine.py").read(), "see_fine.py", 'exec'))










