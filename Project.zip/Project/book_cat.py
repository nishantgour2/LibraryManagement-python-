#!/usr/bin/env python
# coding: utf-8

# In[11]:


# see category

class book_cate:
   
    
    
    def display(self):
        
        
        
        self.list1=['Algorithms and data structures','Artificial intelligence','Computational science‎',
         'Computer architecture‎' ,'Computer graphics‎ ', 'Computer security‎ ', 'Concurrency (computer science)‎'
        ,  'Database theory‎ ', 'Formal methods‎', 'Human-based computation‎' , 'Human–computer interaction‎'
        ,  'Mathematical optimization‎', 'Programming language theory‎' ,'Soft computing‎' , 'Software engineering‎'
        ,  'Theoretical computer science‎', 'Theory of computation‎ ']
            
        print("\n".join(self.list1))  
        
c= book_cate()
c.display()

import pickle
with open("Book_cat.pkl","wb") as f:
    pickle.dump(c.list1,f)
    
input()    



# In[ ]:




